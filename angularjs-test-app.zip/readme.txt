This script is a modified version of https://scotch.io/tutorials/single-page-apps-with-angularjs-routing-and-templating
Made more SEO friendly by Allotment.digital 

YOU SHOULD EDIT THE script.js FILE BEFORE PUTTING LIVE

Full write up: https://allotment.digital/learn/technical-seo/advanced-concepts/angularjs-seo/
