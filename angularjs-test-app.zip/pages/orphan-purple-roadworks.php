    <div class="jumbotron text-center">
        <h1>Orphan Purple Roadworks</h1>

        <p>This page is linked to only from the Applause Rudder Teapot page - meaning that for a crawlwer to discover this URL, they would have to render and follow the link from that page.</p>
        <p>This is an essential requirement if search engines want to correctly index JS-only websites.</p>
    </div>
	