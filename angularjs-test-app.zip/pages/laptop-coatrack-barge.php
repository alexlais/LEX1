    <div class="jumbotron text-center">
        <h1>Laptop Coatrack Barge</h1>

        <p>When you're out and about in the big city, the last thing you want is to be dragging your laptop around. Laptop coatracks were introduced in late 2010 to help to solve this problem, however, it was discovered six months later that users of these revolutionary devices were forced to carry their laptop coatracks around - compounding the problem</p>
		<p>At angular.abertram.com, we have pioneered the laptop coatrack barge - these ingenious devices are designed to float in the nearest river or body of water and store your laptop coatracks</p>
		<p>Our barges for laptop coatracks are custom made to ensure a perfect fit, so delivery can take up to 7 days. For more info, contact the team at bargesforlaptopcoatracks@abertram.com</p>
    </div>
	