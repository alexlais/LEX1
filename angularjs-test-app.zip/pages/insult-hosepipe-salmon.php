    <div class="jumbotron text-center">
        <h1>Insult Hosepipe Salmon</h1>
		<p><strong>We have used the robots tag to request that crawlers do not index this URL</strong></p>
        <p>I thought that I would share with you my favourite joke - I bring this out at every party I go to, and it always brings the house down.</p>
		<p>Three salmon walk into a bar. The barman says "What'll it be boys?". The salmon order a bottle of house red and enjoy it. Later that night they go home.</p>
		<p>I told this joke last week at a wedding, to my dismay someone in the audience had brought a hosepipe with them. As you can probably guess, the hosepipe was very insulted by my little tale.</p>
		<p>Moral of the story: Don't tell jokes about salmon until you've checked for hosepipes who are easily offended.</p>
    </div>