    <div class="jumbotron text-center">
        <h1>Applause Rudder Teapot</h1>

        <p>If you're a crawler and have rendered this page, you should definitely look at the <a href="/orphan-purple-roadworks">Orphan Purple Roadworks</a> page. I first came up with the idea of a rudder teapot for applausing when I was having a cheeky nandos with the lads last week. The basic process involves taking your rudder teapot (alternatively you could use your teapot's rudder, but we'll get to that another time) and adding an applause track. This method is common sitcoms - Friends and Big Bang Theory are examples of shows that pioneered this technique.</p>
		<p>If you don't like applause tracks, you can of course use a laugh track, screaming track, or indeed any other track that you have to hand.</p>
    </div>